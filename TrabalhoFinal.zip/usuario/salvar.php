<?php

include_once ("../servico/BD.php");

$login = $_GET["login"];
$senha = $_GET["senha"];

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $sql = "update Usuário set login='$login',  senha='$senha' where id='$id' ";
}else {
    $sql = "INSERT INTO `Usuário` (`id`, `login`, `senha`) VALUES (NULL, '$login', '$senha')";    
}


$bd = new BD();
$contador = $bd->exec($sql); 

echo "<h1> Foi incluído/atualizado $contador registro </h1>";

echo "<a href='consultaUsuario.php'>Voltar </a>";

?>